import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  try {
    console.log('--------------------------------');
    console.log('🔒 Middleware triggered');
    console.log('URL:', request.url);
    
    const response = NextResponse.next();
    response.headers.set('x-middleware-cache', 'no-cache');
    
    return response;
  } catch (error) {
    console.error('Middleware error:', error);
    return NextResponse.next();
  }
}

// Simpler matcher configuration
export const config = {
  matcher: '/((?!_next/static|_next/image|favicon.ico).*)',
};

import { NextResponse } from 'next/server';
import { NextRequest } from 'next/server';

// Remove async as it's not needed for synchronous operations
export function middleware(request: NextRequest) {
  // Basic console log to check if middleware is running
  console.log('⭐️ Middleware executing for:', request.nextUrl.pathname);

  // Add a custom header to verify middleware execution in network tab
  const response = NextResponse.next();
  response.headers.set('x-middleware-check', 'active');
  
  // No token check for now, just log and proceed
  const token = request.cookies.get('token');
  console.log('Token present:', !!token);

  return response;
}

// Update matcher to catch ALL routes except static files
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next
     * - static (static files)
     * - images (image files)
     * - favicon.ico
     */
    '/((?!_next|static|images|favicon.ico).*)',
  ]
};
